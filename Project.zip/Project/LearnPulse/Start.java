public class Start {

    public static void main(String[] args) {
        Student[] blankStudents = new Student[1];
        new Login(blankStudents);
    }
}
